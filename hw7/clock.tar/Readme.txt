Homework 7, ECE 474

Author: Zongzhe Bi

Student ID: 932784769

Simulation: "sh doit".
